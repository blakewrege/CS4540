# CS4540
##Operating Systems Assignment 6
-Note: requires 4.4.* kernal
1. sudo dmesg -c
2. make
3. sudo insmod ProjectA6.ko
4. sudo rmmod ProjectA6
4. sudo dmesg > dmesg-output.txt
6. chown blake dmesg-output.txt
7. cat dmesg-output.txt

