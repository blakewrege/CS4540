# CS4540
-Note: requires 4.4.* kernal
##Operating Systems Assignment 6
1. Run "make"
2. sudo insmod simple.ko
4. Type ./A5P1.out to run program
