# CS4540
-Note: run all as root user
##Operating Systems Assignment 6
1. dmesg -c
2. make
3. insmod ProjectA6.ko
4. rmmod ProjectA6
4. dmesg > dmesg-output.txt
7. cat dmesg-output.txt
